Code and Data main contains final work
Upload the data files to the created folder on drive (nyc-crime-analysis/data)
Supplementary folder contains the notebooks used for experimentation throughout the project


